package nazario.liby.api.lang;

import nazario.liby.internal.client.LibyLanguageResourceLoader;

import java.util.function.Consumer;

public interface LibyLanguageRegistryAccess {
    void add(String modId, String languageId, Consumer<LibyLanguage.Builder> builderConsumer);
    void addAll(LibyLanguage... languages);
}
