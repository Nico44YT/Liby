package nazario.liby.api.lang;

import com.google.gson.*;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

public class LibyLanguage {
    private String modId;
    private String id;
    private Map<String, String> keys;

    private LibyLanguage(String modId, String id) {
        this(modId, id, new HashMap<>());
    }

    private LibyLanguage(String modId, String id, Map<String, String> keys) {
        this.modId = modId;
        this.id = id;
        this.keys = keys;
    }

    public static LibyLanguage of(String modId, String id, Map<String, String> keys) {
        return new LibyLanguage(modId, id, keys);
    }

    public static LibyLanguage fromFile(Identifier fileId, Resource fileResource) {
        try{
            String modId = fileId.getNamespace();
            String languageId = fileId.getPath().split("\\.")[0];
            LibyLanguage.Builder languageBuilder = new LibyLanguage.Builder(modId, languageId);

            JsonObject jsonObject = JsonParser.parseReader(fileResource.getReader()).getAsJsonObject();

            Map<String, JsonElement> elements = jsonObject.asMap();

            addMapToKey(null, elements, languageBuilder);

            return languageBuilder.build();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void addMapToKey(String prevKeys, Map<String, JsonElement> elementMap, LibyLanguage.Builder builder) {
        for(String key : elementMap.keySet()) {
            String newKey;

            if(prevKeys != null) newKey = prevKeys + "." + key;
            else newKey = key;

            JsonElement element = elementMap.get(key);

            if(element instanceof JsonPrimitive primitive) {
                builder.addKey(newKey, primitive.getAsString());
                continue;
            }

            if(element instanceof JsonArray array) {
                for(int i = 0;i<array.size();i++) {
                    JsonElement arrayElement = array.get(i);
                    if(arrayElement instanceof JsonPrimitive primitive) {
                        builder.addKey(newKey + "_" + i, primitive.getAsString());
                    } else {
                        throw new UnsupportedOperationException("Only primitives are allowed in json arrays for liby language files");
                    }
                }
                continue;
            }

            if(element instanceof JsonObject object) {
                addMapToKey(newKey, object.asMap(), builder);
                continue;
            }
        }
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getKeys() {
        return keys;
    }

    public String getModId() {
        return modId;
    }

    public static class Builder {
        LibyLanguage language;

        public Builder(String modId, String id) {
            this.language = new LibyLanguage(modId, id);
        }

        public Builder addKey(String key, String value) {
            language.keys.put(key, value);
            return this;
        }

        public LibyLanguage build() {
            return this.language;
        }
    }
}