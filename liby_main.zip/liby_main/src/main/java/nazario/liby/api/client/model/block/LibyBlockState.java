package nazario.liby.api.client.model.block;

import com.google.gson.JsonElement;
import net.minecraft.client.render.model.ModelLoader;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.function.BiConsumer;

public abstract class LibyBlockState {
    public Identifier id;

    public abstract List<Resource> createResourceList();

    public Identifier getId() {
        return this.id;
    }
}
