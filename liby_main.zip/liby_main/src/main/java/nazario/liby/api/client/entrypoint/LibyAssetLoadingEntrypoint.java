package nazario.liby.api.client.entrypoint;

public interface LibyAssetLoadingEntrypoint {
    void onLibyAssetLoading(LibyAssetRegistryAccess registryAccess);
}