package nazario.liby.api.client.model;

import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.util.Identifier;

public interface LibyModel<T> {
    Identifier getId();
    T bake();
}
