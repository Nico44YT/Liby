package nazario.liby.api.client.entrypoint;

import nazario.liby.api.client.model.LibyModel;
import nazario.liby.api.client.model.block.LibyBlockState;
import nazario.liby.api.lang.LibyLanguageRegistryAccess;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;

import java.util.function.BiFunction;
import java.util.function.Function;


public interface LibyAssetRegistryAccess {
    void addModel(LibyModel<?> libyModel);
    void addModels(LibyModel<?>... libyModels);
    void addBlockState(LibyBlockState libyBlockState);
    void addItemPredicateModel(ItemConvertible item, ModelIdentifier modelIdentifier, Function<ModelTransformationMode, Boolean> applyingFunction);
    void addItemPredicateModel(ItemConvertible item, ModelIdentifier modelIdentifier, BiFunction<ModelTransformationMode, ItemStack, Boolean> applyingFunction);
    LibyLanguageRegistryAccess getLanguageRegistry();
}