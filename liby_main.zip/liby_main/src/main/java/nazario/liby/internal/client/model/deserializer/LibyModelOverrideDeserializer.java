package nazario.liby.internal.client.model.deserializer;

import net.minecraft.client.render.model.json.ModelOverride;

public class LibyModelOverrideDeserializer extends ModelOverride.Deserializer {
    public LibyModelOverrideDeserializer() {
        super();
    }
}
