package nazario.liby.internal.client.model;

import com.mojang.datafixers.util.Either;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.ApiStatus;

import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

@ApiStatus.Internal
public record LibyItemPredicateModel(ItemConvertible item, ModelIdentifier modelIdentifier, Either<Function<ModelTransformationMode, Boolean>, BiFunction<ModelTransformationMode, ItemStack, Boolean>> applyingFunction) {
    @Override
    public ItemConvertible item() {
        return item;
    }

    @Override
    public ModelIdentifier modelIdentifier() {
        return modelIdentifier;
    }

    public Either<Function<ModelTransformationMode, Boolean>, BiFunction<ModelTransformationMode, ItemStack, Boolean>> applyingFunction() {
        return this.applyingFunction;
    }

    public Optional<Function<ModelTransformationMode, Boolean>> applyingFunctionBasic() {
        return applyingFunction.left();
    }

    public Optional<BiFunction<ModelTransformationMode, ItemStack, Boolean>> applyingFunctionItemStack() {
        return applyingFunction.right();
    }
}