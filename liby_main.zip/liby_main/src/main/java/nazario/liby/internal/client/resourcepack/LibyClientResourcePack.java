package nazario.liby.internal.client.resourcepack;

import nazario.liby.LibyMain;
import nazario.liby.internal.client.LibyAssetRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.resource.ResourceIndex;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.metadata.PackResourceMetadata;
import net.minecraft.resource.metadata.ResourceMetadataReader;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

public class LibyClientResourcePack implements ResourcePack {

    public static Path resourcePath;
    private PackResourceMetadata metadata;
    private ResourceIndex index;

    public LibyClientResourcePack(PackResourceMetadata packResourceMetadata, ResourceIndex index) {
        this.metadata = packResourceMetadata;
        this.index = index;
    }

    @Override
    public @Nullable InputSupplier<InputStream> openRoot(String... segments) {
        if (segments.length != 1) return null;

        String fileName = segments[0];
        if (fileName.contains("/") || fileName.contains("\\")) {
            throw new IllegalArgumentException("Root resources can only be filenames, not paths (no / or \\ allowed!)");
        }

        Path path;
        if (resourcePath != null) {
            if (Files.exists(path = resourcePath.resolve(fileName))) {
                return () -> Files.newInputStream(path);
            }
        }

        InputStream stream = getInputStream(fileName);
        if (stream == null) return null;
        return () -> stream;
    }

    @Nullable
    protected InputStream getInputStream(String path) {
        return LibyClientResourcePack.class.getResourceAsStream("/" + path);
    }

    @Override
    public InputSupplier<InputStream> open(ResourceType type, Identifier id) {
        if (type == ResourceType.CLIENT_RESOURCES) {

            System.out.println(id);

            if(id.getPath().equals("sounds.json") || id.getPath().startsWith("lang/")) return null;

            if(!contains(type, id)) return null;

            System.out.println(id);
            System.exit(-44);

            try{
                Path path = resourcePath.resolve(type.getDirectory())
                        .resolve(id.getNamespace())
                        .resolve(id.getPath());

                if (Files.exists(path)) {
                    return () -> Files.newInputStream(path);
                }

                InputStream fallback = getInputStream(type.getDirectory() + "/" + id.getNamespace() + "/" + id.getPath());
                if (fallback != null) return () -> fallback;
            }catch (Exception e) {

            }
        }
        return null;
    }
    @Override
    public void findResources(ResourceType type, String namespace, String prefix, ResultConsumer consumer) {
        if (type != ResourceType.CLIENT_RESOURCES) return;

        if(FabricLoader.getInstance().isDevelopmentEnvironment()) LibyMain.LOGGER.info("[Liby-Pack] trying to find {}:{}", namespace, prefix);

        if(resourcePath == null) return;

        Path base = resourcePath.resolve(type.getDirectory()).resolve(namespace);
        try {
            if (Files.exists(base)) {
                Files.walk(base)
                        .filter(Files::isRegularFile)
                        .forEach(path -> {
                            String relative = base.relativize(path).toString().replace(File.separator, "/");
                            if (relative.startsWith(prefix)) {
                                Identifier id = new Identifier(namespace, relative);
                                consumer.accept(id, InputSupplier.create(path));
                            }
                        });
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean contains(ResourceType type, Identifier id) {
        if (type == ResourceType.SERVER_DATA) return false;

        if(FabricLoader.getInstance().isDevelopmentEnvironment()) LibyMain.LOGGER.info("[Liby-Pack] contains \"{}\"?", id);

        String[] parts = id.getPath().split("/");

        if(parts[0].equals("models/")) {
            return LibyAssetRegistry.get("ResourcePack").containsModel(Identifier.of(id.getNamespace(), parts[parts.length-1].replace(".json","")));
        }

        if(parts[0].equals("lang/")) {
            System.out.println(id);
            return true;
        }

        //Path path = resourcePath.resolve(type.getDirectory())
        //        .resolve(id.getNamespace())
        //        .resolve(id.getPath());
//
        //return Files.exists(path);
        return false;
    }

    @Override
    public Set<String> getNamespaces(ResourceType type) {
        if(type.equals(ResourceType.SERVER_DATA)) return Set.of();

        return LibyResourcePackProvider.getAllNamespaces();
    }

    @Override
    @Nullable
    public <T> T parseMetadata(ResourceMetadataReader<T> metaReader) throws IOException {
        if (metaReader != PackResourceMetadata.SERIALIZER) return null;
        return (T)this.metadata;
    }

    @Override
    public String getName() {
        return "Liby Dynamic Assets";
    }

    @Override
    public void close() {
        // No resources to close currently
    }
}
