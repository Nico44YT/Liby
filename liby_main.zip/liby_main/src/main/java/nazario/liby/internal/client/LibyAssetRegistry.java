package nazario.liby.internal.client;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;

import nazario.liby.LibyMain;
import nazario.liby.api.client.model.LibyModel;
import nazario.liby.api.client.entrypoint.LibyAssetRegistryAccess;
import nazario.liby.api.client.entrypoint.LibyAssetLoadingEntrypoint;
import nazario.liby.api.client.model.block.LibyBlockState;
import nazario.liby.api.lang.LibyLanguageRegistryAccess;
import nazario.liby.api.client.model.obj.LibyObjModel;
import nazario.liby.internal.client.model.LibyItemPredicateModelRegistry;
import nazario.liby.internal.registry.LibyLanguageRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class LibyAssetRegistry implements LibyAssetRegistryAccess {
    private static LibyAssetRegistry INSTANCE;

    @Environment(EnvType.CLIENT)
    public static LibyAssetRegistry get(String placeWhereCreated) {
        if(INSTANCE == null) {
            INSTANCE = new LibyAssetRegistry();

            FabricLoader.getInstance()
                    .getEntrypoints("liby_asset_loader", LibyAssetLoadingEntrypoint.class)
                    .forEach(entrypoint -> entrypoint.onLibyAssetLoading(LibyAssetRegistry.get(placeWhereCreated)));

            LibyMain.LOGGER.info("[Liby] Loaded entrypoints at " + placeWhereCreated);

        }
        return INSTANCE;
    }

    private final LibyLanguageRegistry languageRegistry;
    
    private final Set<LibyModel<?>> modelSet;
    private final Set<LibyBlockState> blockstateSet;
    private final LibyItemPredicateModelRegistry itemPredicateModelRegistry;

    private final Map<Identifier, LibyObjModel> OBJ_MODELS;
    
    public LibyAssetRegistry() {
        this.languageRegistry = new LibyLanguageRegistry();

        this.modelSet = new HashSet<>();
        this.blockstateSet = new HashSet<>();
        this.itemPredicateModelRegistry = new LibyItemPredicateModelRegistry();

        this.OBJ_MODELS = new HashMap<>();
    }
    
    @Override
    public void addModel(LibyModel<?> libyModel) {
        this.modelSet.add(libyModel);
    }

    @Override
    public void addModels(LibyModel<?>... libyModels) {
        this.modelSet.addAll(Arrays.asList(libyModels));
    }

    @Override
    public void addBlockState(LibyBlockState libyBlockState) {
        this.blockstateSet.add(libyBlockState);
    }

    @Override
    public void addItemPredicateModel(ItemConvertible item, ModelIdentifier modelIdentifier, Function<ModelTransformationMode, Boolean> applyingFunction) {
        this.itemPredicateModelRegistry.add(item, modelIdentifier, applyingFunction);
    }

    @Override
    public void addItemPredicateModel(ItemConvertible item, ModelIdentifier modelIdentifier, BiFunction<ModelTransformationMode, ItemStack, Boolean> applyingFunction) {
        this.itemPredicateModelRegistry.add(item, modelIdentifier, applyingFunction);
    }


    @Override
    public LibyLanguageRegistryAccess getLanguageRegistry() {
        return this.languageRegistry;
    }

    public Set<LibyModel<?>> getModels() {
        return this.modelSet;
    }

    public boolean containsModel(Identifier id) {
        return this.modelSet.stream().anyMatch(model -> model.getId().equals(id));
    }

    public Set<LibyBlockState> getBlockstates() {
        return this.blockstateSet;
    }

    public LibyItemPredicateModelRegistry getItemPredicateModelsRegistry() {
        return this.itemPredicateModelRegistry;
    }

    public void registerObjModel(Identifier identifier, LibyObjModel objModel) {
        this.OBJ_MODELS.put(identifier, objModel);
    }
}