package nazario.liby.internal.registry;

import nazario.liby.api.lang.LibyLanguage;
import nazario.liby.api.lang.LibyLanguageRegistryAccess;
import org.jetbrains.annotations.ApiStatus;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

@ApiStatus.Internal
public class LibyLanguageRegistry implements LibyLanguageRegistryAccess {

    private static final Set<LibyLanguage> languages = new HashSet<>();

    @Override
    public void add(String modId, String languageId, Consumer<LibyLanguage.Builder> builderConsumer) {
        LibyLanguage.Builder builder = new LibyLanguage.Builder(modId, languageId);
        builderConsumer.accept(builder);
        languages.add(builder.build());
    }

    @Override
    public void addAll(LibyLanguage... language) {
        languages.addAll(List.of(language));
    }

    public Set<LibyLanguage> getLanguages() {
        return languages;
    }
}
