package nazario.liby.internal.client.model.deserializer;

import net.minecraft.client.render.model.json.ModelElementTexture;

public class LibyModelElementTextureDeserializer extends ModelElementTexture.Deserializer {
    public LibyModelElementTextureDeserializer() {
        super();
    }
}
