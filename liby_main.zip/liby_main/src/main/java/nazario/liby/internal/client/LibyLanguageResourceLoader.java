package nazario.liby.internal.client;

import nazario.liby.LibyMain;
import nazario.liby.api.lang.LibyLanguage;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class LibyLanguageResourceLoader implements IdentifiableResourceReloadListener {

    private static LibyLanguageResourceLoader instance;
    private final HashMap<Identifier, LibyLanguage> languageMap = new HashMap<>();
    private final Identifier identifier;

    public LibyLanguageResourceLoader(Identifier identifier) {
        this.identifier = identifier;
        instance = this;

        LibyMain.LOGGER.info("[Liby] Created Language Loader");
    }

    @Override
    public Identifier getFabricId() {
        return this.identifier;
    }

    @Override
    public CompletableFuture<Void> reload(Synchronizer synchronizer, ResourceManager manager, Profiler prepareProfiler, Profiler applyProfiler, Executor prepareExecutor, Executor applyExecutor) {
        try{
            LibyMain.LOGGER.info("[Liby-Lang] Starting to load languages.");

            CompletableFuture<HashMap<Identifier, LibyLanguage>> languageMapFuture = CompletableFuture.supplyAsync(() -> {
                String startingPath = "lang";
                HashMap<Identifier, LibyLanguage> libyLanguageHashMap = new HashMap<>();

                Map<Identifier, List<Resource>> files = manager.findAllResources(startingPath, Objects::nonNull);
                LibyMain.LOGGER.info("[Liby-Lang] Collected {} files", files.size());

                files.forEach((fileId, fileResourceList) -> {

                    if(fileId.getPath().startsWith(startingPath) && (fileId.getPath().endsWith(".liby.jsonc") || fileId.getPath().endsWith(".liby.json"))) {
                        fileResourceList.forEach(fileResource -> {
                            libyLanguageHashMap.put(fileId, LibyLanguage.fromFile(fileId, fileResource));

                            if(FabricLoader.getInstance().isDevelopmentEnvironment()) {
                                LibyMain.LOGGER.info("[Liby-Lang] loaded \"{}\"", fileId);
                            }
                        });
                    }
                });

                return libyLanguageHashMap;
            });

            return languageMapFuture.thenCompose(synchronizer::whenPrepared).thenAcceptAsync(prepareData -> {
                if(prepareData != null) languageMap.putAll(prepareData);

                LibyMain.LOGGER.info("[Liby-Lang] Put all languages into the language map.");
            });
        } catch (Exception e) {
            LibyMain.LOGGER.error("[Liby-Lang] An error occurred trying to a language file:");
            e.printStackTrace();
            return null;
        }
    }

    public static LibyLanguageResourceLoader getInstance() {
        return instance;
    }

    public HashMap<Identifier, LibyLanguage> getLanguageMap() {
        return this.languageMap;
    }
}
