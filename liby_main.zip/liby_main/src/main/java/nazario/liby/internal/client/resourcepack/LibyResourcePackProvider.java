package nazario.liby.internal.client.resourcepack;

import nazario.liby.api.client.entrypoint.LibyAssetLoadingEntrypoint;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.SharedConstants;
import net.minecraft.client.resource.ResourceIndex;
import net.minecraft.resource.*;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.resource.metadata.PackResourceMetadata;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

public class LibyResourcePackProvider implements ResourcePackProvider, ResourcePackProfile.PackFactory {
    public static final ResourcePackSource SOURCE = ResourcePackSource.create((text) -> text, true);

    private static LibyResourcePackProvider INSTANCE;
    public static LibyResourcePackProvider get() {
        if(INSTANCE == null) INSTANCE = new LibyResourcePackProvider();
        return INSTANCE;
    }

    ResourcePack pack;
    ResourceIndex index;
    ResourcePackProfile.Metadata metadata;

    public LibyResourcePackProvider() {
        int format = SharedConstants.getGameVersion().getResourceVersion(ResourceType.CLIENT_RESOURCES);
        this.index = null;
        this.pack = new LibyClientResourcePack(new PackResourceMetadata(Text.translatable("liby.resourcepack.description", String.valueOf(getAllNamespaces().size())), format), this.index);
        this.metadata = new ResourcePackProfile.Metadata(
                Text.translatable("liby.resourcepack.description"),
                format,
                FeatureSet.empty()
        );
    }

    @Override
    public void register(Consumer<ResourcePackProfile> profileAdder) {

        ResourcePackProfile profile = ResourcePackProfile.of(
                "liby_dynamic_resources",
                Text.translatable("liby.resourcepack.name"),
                true,
                this,
                this.metadata,
                ResourceType.CLIENT_RESOURCES,
                ResourcePackProfile.InsertionPosition.TOP,
                false,
                SOURCE
        );

        profileAdder.accept(profile);
    }

    @Override
    public ResourcePack open(String name) {
        return this.pack;
    }

    public ResourcePack getPack() {
        return pack;
    }

    public static Set<String> getAllNamespaces() {
        Set<String> namespaces = new HashSet<>();

        FabricLoader.getInstance().getEntrypointContainers("liby_asset_loader", LibyAssetLoadingEntrypoint.class).forEach(container -> {
            namespaces.add(container.getProvider().getMetadata().getId());
        });


        //namespaces.addAll(LibyAssetRegistry.get("PackProvider").getModels()
        //        .stream()
        //        .map(libyModel -> libyModel.getId().getNamespace())
        //        .toList());
//
        //namespaces.addAll(LibyAssetRegistry.get("PackProvider").getBlockstates()
        //        .stream()
        //        .map(libyBlockState -> libyBlockState.getId().getNamespace())
        //        .toList());
//
        //namespaces.addAll(((LibyLanguageRegistry)LibyAssetRegistry.get("PackProvider").getLanguageRegistry()).getLanguages()
        //        .stream()
        //        .map(LibyLanguage::getModId)
        //        .toList());

        return namespaces;
    }
}
