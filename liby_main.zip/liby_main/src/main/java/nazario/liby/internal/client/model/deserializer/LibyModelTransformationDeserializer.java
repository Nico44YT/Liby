package nazario.liby.internal.client.model.deserializer;

import net.minecraft.client.render.model.json.ModelTransformation;

public class LibyModelTransformationDeserializer extends ModelTransformation.Deserializer {
    public LibyModelTransformationDeserializer() {
        super();
    }
}
