package nazario.liby.internal.client.model.deserializer;

import net.minecraft.client.render.model.json.Transformation;

public class LibyTransformationDeserializer extends Transformation.Deserializer {
    public LibyTransformationDeserializer() {
        super();
    }
}
