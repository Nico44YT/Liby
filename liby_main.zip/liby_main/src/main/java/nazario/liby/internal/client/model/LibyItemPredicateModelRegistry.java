package nazario.liby.internal.client.model;

import java.util.HashSet;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;

import com.mojang.datafixers.util.Either;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class LibyItemPredicateModelRegistry {
    
    public final Set<LibyItemPredicateModel> itemPredicateModelSet;
    
    public LibyItemPredicateModelRegistry() {
        this.itemPredicateModelSet = new HashSet<>();
    }
    
    public void add(ItemConvertible item, ModelIdentifier modelIdentifier, Function<ModelTransformationMode, Boolean> applyingFunction) {
        this.itemPredicateModelSet.add(new LibyItemPredicateModel(item, modelIdentifier, Either.left(applyingFunction)));
    }

    public void add(ItemConvertible item, ModelIdentifier modelIdentifier, BiFunction<ModelTransformationMode, ItemStack, Boolean> applyingFunction) {
        this.itemPredicateModelSet.add(new LibyItemPredicateModel(item, modelIdentifier, Either.right(applyingFunction)));
    }

    public Set<LibyItemPredicateModel> getPredicateModels() {
        return this.itemPredicateModelSet;
    }
}