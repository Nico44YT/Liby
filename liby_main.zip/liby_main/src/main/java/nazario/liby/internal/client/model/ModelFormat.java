package nazario.liby.internal.client.model;

public enum ModelFormat {
    VANILLA_OR_OTHER,
    LIBY,
    LIBY_OBJ,
    NONE
}
