package nazario.liby.internal.client.model.deserializer;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import nazario.liby.internal.client.model.LibyFreeFormRotation;
import net.minecraft.client.render.model.json.ModelElement;
import net.minecraft.client.render.model.json.ModelElementFace;
import net.minecraft.client.render.model.json.ModelRotation;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.lang.reflect.Type;
import java.util.Map;

public class LibyModelElementDeserializer extends ModelElement.Deserializer {
    public LibyModelElementDeserializer() {
        super();
    }

    @Override
    public ModelElement deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        JsonObject elementObject = jsonElement.getAsJsonObject();
        Vector3f from = this.deserializeVec3f(elementObject, "from");
        Vector3f to = this.deserializeVec3f(elementObject, "to");
        Map<Direction, ModelElementFace> facesMap = this.deserializeFacesValidating(jsonDeserializationContext, elementObject);

        ModelRotation modelRotation = this.liby$deserializeRotation(elementObject);

        boolean shade = elementObject.has("shade") ? elementObject.get("shade").getAsBoolean() : true;

        return new ModelElement(from, to, facesMap, modelRotation, shade);
    }

    @Nullable
    public ModelRotation liby$deserializeRotation(JsonObject object) {
        ModelRotation modelRotation = null;
        if (object.has("rotation")) {
            LibyFreeFormRotation libyFreeFormRotation = LibyFreeFormRotation.deserializeRotation(object.getAsJsonObject());

            libyFreeFormRotation.getOrigin().mul(1/16f);

            modelRotation = new ModelRotation(null, null, 0, false);
            modelRotation.liby$setFreeFormRotation(libyFreeFormRotation);
        }

        return modelRotation;
    }


}
