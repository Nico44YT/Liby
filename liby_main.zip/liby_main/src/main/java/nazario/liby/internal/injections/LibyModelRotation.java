package nazario.liby.internal.injections;

import nazario.liby.internal.client.model.LibyFreeFormRotation;

public interface LibyModelRotation {
    default LibyFreeFormRotation liby$getFreeFormRotation() {
        return null;
    }

    default void liby$setFreeFormRotation(LibyFreeFormRotation libyFreeFormRotation) {

    }

    default boolean liby$isLibyFreeFormSet() {
        return false;
    }
}
