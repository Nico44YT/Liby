package nazario.liby.internal.client.model.deserializer;

import net.minecraft.client.render.model.json.ModelElementFace;

public class LibyModelElementFaceDeserializer extends ModelElementFace.Deserializer {
    public LibyModelElementFaceDeserializer() {
        super();
    }
}
