package nazario.liby.client;

import nazario.liby.LibyMain;
import nazario.liby.internal.client.LibyObjResourceLoader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

public class LibyClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        LibyMain.LOGGER.info("Liby Client Initialized");

        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new LibyObjResourceLoader(Identifier.of("liby", "obj_loader")));
        //ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new LibyLanguageResourceLoader(Identifier.of("liby", "language_loader")));
    }
}
