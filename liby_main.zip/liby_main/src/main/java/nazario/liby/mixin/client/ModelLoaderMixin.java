
package nazario.liby.mixin.client;

import nazario.liby.api.client.model.LibyJsonModel;
import nazario.liby.internal.client.LibyAssetRegistry;
import nazario.liby.api.client.model.obj.LibyObjModel;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.render.model.ModelLoader;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;

@Mixin(ModelLoader.class)
public abstract class ModelLoaderMixin {
    @Shadow @Final private Map<Identifier, UnbakedModel> unbakedModels;

    @Shadow @Final private Map<Identifier, UnbakedModel> modelsToBake;

    @Shadow protected abstract void addModel(ModelIdentifier modelId);

    @Shadow @Final private Map<Identifier, List<ModelLoader.SourceTrackedData>> blockStates;

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V"))
    private void liby$loadEntrypoints(BlockColors blockColors, Profiler profiler, Map<Identifier, UnbakedModel> jsonUnbakedModels, Map<Identifier, UnbakedModel> blockStates, CallbackInfo ci) {
        LibyAssetRegistry.get("ModelLoader").getModels().forEach(libyModel -> {

            Object baked = libyModel.bake();

            if(baked instanceof UnbakedModel unbakedModel) {
                this.unbakedModels.put(libyModel.getId(), unbakedModel);
                this.modelsToBake.put(libyModel.getId(), unbakedModel);
            } else if(libyModel instanceof LibyObjModel objModel) {
                LibyAssetRegistry.get("ModelLoader").registerObjModel(objModel.getId(), objModel);
            }

        });
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/model/ModelLoader;addModel(Lnet/minecraft/client/util/ModelIdentifier;)V", ordinal = 3, shift = At.Shift.AFTER))
    public void liby$loadItemModelPredicates(BlockColors blockColors, Profiler profiler, Map<Identifier, UnbakedModel> jsonUnbakedModels, Map<Identifier, UnbakedModel> blockStates, CallbackInfo ci) {
        LibyAssetRegistry.get("ModelLoader").getItemPredicateModelsRegistry().getPredicateModels().forEach(model -> this.addModel(model.modelIdentifier()));
    }

    @Inject(method = "loadModelFromJson", at = @At("HEAD"), cancellable = true)
    public void liby$loadModelFromJson(Identifier id, CallbackInfoReturnable<JsonUnbakedModel> cir) {
        LibyAssetRegistry.get("ModelLoader").getModels().forEach(model -> {
            if (model.getId().equals(id)) {
                if(model instanceof LibyJsonModel jsonModel) {
                    if(jsonModel.bake() instanceof JsonUnbakedModel jsonUnbakedModel) {
                        cir.setReturnValue(jsonUnbakedModel);
                        return;
                    }
                }
            }
        });
    }
}
