package nazario.liby.mixin.manager;

import com.google.common.collect.ImmutableSet;
import nazario.liby.internal.client.resourcepack.LibyResourcePackProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resource.ResourcePackManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Mixin(ResourcePackManager.class)
public abstract class ResourcePackManagerMixin {

    @Environment(EnvType.CLIENT)
    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lcom/google/common/collect/ImmutableSet;copyOf([Ljava/lang/Object;)Lcom/google/common/collect/ImmutableSet;"), remap = false)
    public <E> ImmutableSet<E> liby$injectResourcePackProvider(E[] oldProviders) {
        Set<E> newProviders = new HashSet<>(List.of(oldProviders));

        newProviders.add((E)LibyResourcePackProvider.get());

        return ImmutableSet.copyOf(newProviders);
    }
}
