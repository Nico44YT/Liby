package nazario.liby.mixin;

import nazario.liby.LibyMain;
import nazario.liby.api.util.LibyIdentifier;
import nazario.liby.internal.client.LibyAssetRegistry;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceFinder;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

@Mixin(ResourceFinder.class)
public abstract class ResourceFinderMixin {
    @Redirect(method = "findAllResources", at = @At(value = "INVOKE", target = "Lnet/minecraft/resource/ResourceManager;findAllResources(Ljava/lang/String;Ljava/util/function/Predicate;)Ljava/util/Map;"))
    public Map<Identifier, List<Resource>> livy$injectResources(ResourceManager instance, String s, Predicate<Identifier> identifierPredicate) {
        HashMap<Identifier, List<Resource>> map = new HashMap<>(instance.findAllResources(s, identifierPredicate));

        LibyMain.LOGGER.debug("[Liby] Finding resources for \"{}\"", s);

        if("blockstates".equals(s)) {
            LibyAssetRegistry.get("ResourceFinder").getBlockstates().forEach(libyBlockState -> map.put(
                    new LibyIdentifier(libyBlockState.getId()).prependPath("blockstates/").appendPath(".json"),
                    libyBlockState.createResourceList()));
        }

        return map;
    }
}
