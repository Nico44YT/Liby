package nazario.liby.mixin.client;

import nazario.liby.internal.client.model.LibyFreeFormRotation;
import nazario.liby.internal.injections.LibyModelRotation;
import net.minecraft.client.render.model.json.ModelRotation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ModelRotation.class)
public abstract class ModelRotationInjection implements LibyModelRotation {

    @Unique
    private boolean isSet;
    @Unique
    private LibyFreeFormRotation libyFreeFormRotation;

    @Override
    public LibyFreeFormRotation liby$getFreeFormRotation() {
        return libyFreeFormRotation;
    }

    @Override
    public void liby$setFreeFormRotation(LibyFreeFormRotation libyFreeFormRotation) {
        this.isSet = true;
        this.libyFreeFormRotation = libyFreeFormRotation;
    }

    @Override
    public boolean liby$isLibyFreeFormSet() {
        return this.isSet;
    }
}
