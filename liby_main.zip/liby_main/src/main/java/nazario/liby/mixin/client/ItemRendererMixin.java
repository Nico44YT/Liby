package nazario.liby.mixin.client;

import nazario.liby.api.item.LibyCustomItemRenderer;
import nazario.liby.internal.client.model.LibyItemPredicateModel;
import nazario.liby.internal.client.LibyAssetRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.BuiltinModelItemRenderer;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedModelManager;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Shadow @Final private TextureManager textureManager;

    @Shadow @Final private ItemColors colors;

    @Shadow @Final private BuiltinModelItemRenderer builtinModelItemRenderer;

    @Unique
    private BakedModelManager bakery;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void liby$init(MinecraftClient client, TextureManager manager, BakedModelManager bakery, ItemColors colors, BuiltinModelItemRenderer builtinModelItemRenderer, CallbackInfo ci) {
        this.bakery = bakery;
    }

    @Inject(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", ordinal = 0), cancellable = true)
    public void liby$renderItem(ItemStack stack, ModelTransformationMode renderMode, boolean leftHanded, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay, BakedModel model, CallbackInfo ci) {
        if(stack != null && !stack.isEmpty()) {
            if(stack.getItem() instanceof LibyCustomItemRenderer itemRenderer) {
                itemRenderer.getRenderer(client, textureManager, bakery, colors, builtinModelItemRenderer)
                        .renderItem(stack, renderMode, leftHanded, matrices, vertexConsumers, light, overlay, model);
                ci.cancel();
            }
        }
    }

    @SuppressWarnings("all")
    @ModifyVariable(method = "renderItem", at = @At("HEAD"), argsOnly = true)
    public BakedModel liby$renderItem(BakedModel value, ItemStack stack, ModelTransformationMode renderMode, boolean leftHanded, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        List<LibyItemPredicateModel> predicateModels = LibyAssetRegistry.get("ItemRenderer").getItemPredicateModelsRegistry().getPredicateModels().stream().filter(predicate -> predicate.item().asItem().equals(stack.getItem())).toList();

        for (LibyItemPredicateModel predicateModel : predicateModels) {
            boolean shouldRender = false;

            if(predicateModel.applyingFunctionBasic().isPresent() && predicateModel.applyingFunctionBasic().get().apply(renderMode)) shouldRender = true;
            if(predicateModel.applyingFunctionItemStack().isPresent() && predicateModel.applyingFunctionItemStack().get().apply(renderMode, stack)) shouldRender = true;

            if(shouldRender) return ((ItemRendererAccessor)this).getItemModels().getModelManager().getModel(predicateModel.modelIdentifier());
        }

        return value;
    }

}
