package nazario.liby.mixin.manager;

import nazario.liby.api.lang.LibyLanguage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.resource.language.TranslationStorage;
import net.minecraft.resource.Resource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
@Mixin(TranslationStorage.class)
public abstract class TranslationStorageMixin {

    @Inject(method = "load(Ljava/lang/String;Ljava/util/List;Ljava/util/Map;)V", at = @At("TAIL"))
    private static void liby$injectLanguages(String langCode, List<Resource> resourceRefs, Map<String, String> translations, CallbackInfo ci) {
        //TODO fix languages
        //LibyAssetRegistry.get("TranslationStorage").getLanguageRegistry().addAll(LibyLanguageResourceLoader.getInstance().getLanguageMap().values().toArray(LibyLanguage[]::new));
//
        //Optional<LibyLanguage> optional = ((LibyLanguageRegistry) LibyAssetRegistry.get("TranslationStorage").getLanguageRegistry()).getLanguages().stream().filter(lang -> lang.getId().equals(langCode)).findAny();
//
        //optional.ifPresent(libyLanguage -> translations.putAll(libyLanguage.getKeys()));
    }
}
