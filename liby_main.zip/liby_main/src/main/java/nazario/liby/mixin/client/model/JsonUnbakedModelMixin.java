package nazario.liby.mixin.client.model;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import nazario.liby.api.util.LibyGenericUtils;
import nazario.liby.internal.client.model.LibyJsonUnbakedModelDeserializer;
import nazario.liby.internal.client.model.ModelFormat;
import nazario.liby.internal.client.obj.format.LibyObjModelFormatDeserializer;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.util.JsonHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.BufferedReader;
import java.io.Reader;

@Mixin(JsonUnbakedModel.class)
public abstract class JsonUnbakedModelMixin {

    @Shadow @Final private static Gson GSON;

    @Shadow public String id;

    @Inject(method = "deserialize(Ljava/io/Reader;)Lnet/minecraft/client/render/model/json/JsonUnbakedModel;", at = @At("HEAD"), cancellable = true)
    private static void liby$deserializeModel(Reader reader, CallbackInfoReturnable<JsonUnbakedModel> cir) {
        BufferedReader bufferedReader = new BufferedReader(reader);
        JsonElement jsonElement = JsonParser.parseString(LibyGenericUtils.streamToString(bufferedReader.lines(), ""));

        ModelFormat format = liby$checkFormat(jsonElement);

        if(format == ModelFormat.LIBY) {
            cir.setReturnValue(LibyJsonUnbakedModelDeserializer.deserialize(jsonElement.toString()));
            return;
        }

        if(format == ModelFormat.LIBY_OBJ) {
            cir.setReturnValue(LibyObjModelFormatDeserializer.deserialize(jsonElement.toString()));
            return;
        }

        cir.setReturnValue(JsonHelper.deserialize(GSON, jsonElement.toString(), JsonUnbakedModel.class));
    }

    @Inject(method = "deserialize(Ljava/lang/String;)Lnet/minecraft/client/render/model/json/JsonUnbakedModel;", at = @At("HEAD"), cancellable = true)
    private static void liby$deserializeModel(String json, CallbackInfoReturnable<JsonUnbakedModel> cir) {
        JsonElement jsonElement = JsonParser.parseString(json);

        ModelFormat format = liby$checkFormat(jsonElement);

        if (format == ModelFormat.LIBY) {
            cir.setReturnValue(LibyJsonUnbakedModelDeserializer.deserialize(jsonElement.toString()));
            return;
        }

        if (format == ModelFormat.LIBY_OBJ) {
            cir.setReturnValue(LibyObjModelFormatDeserializer.deserialize(jsonElement.toString()));
            return;
        }
    }

    @Unique
    private static ModelFormat liby$checkFormat(JsonElement jsonElement) {
        if(jsonElement instanceof JsonObject jsonObject) {
            if(jsonObject.has("format") && jsonObject.get("format").isJsonPrimitive() && jsonObject.get("format").getAsJsonPrimitive().isString()) {
                String format = jsonObject.get("format").getAsString();

                if(format.equals("liby")) return ModelFormat.LIBY;
                if(format.equals("liby_obj")) return ModelFormat.LIBY_OBJ;
                return ModelFormat.VANILLA_OR_OTHER;
            }
        }

        return ModelFormat.NONE;
    }
}
